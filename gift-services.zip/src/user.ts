import { PubSub, Topic } from '@google-cloud/pubsub';
import { Datastore } from '@google-cloud/datastore';
import { createMessageHandler, createMessageRouter, type Request, type Response } from './common';

interface CreateUserRequest extends Request {
  email: string;
}

interface CreateUserResponse extends Response {
  message?: string;
}

const pubsub = new PubSub({projectId: 'gift-353614'});
const datastore = new Datastore({projectId: 'gift-353614'});

const EventMapping = {
  createUser
}

export async function main() {
  const userServiceSub = await pubsub.subscription('user-service-sub');
  const userOutputTopic = pubsub.topic('user-output');

  userServiceSub.on('message', createMessageHandler(createMessageRouter(EventMapping, userOutputTopic)));
  userServiceSub.on('error', error => {
    console.error('Received error:', error);
    process.exit(1);
  });
}

// Example message: {"type":"createUser","seq": 1, "email":"andrew2@variancestudios.com","from":1}
async function createUser(data: CreateUserRequest, output: Topic) {
  const {email} = data;
  try {
    await datastore.save({
      key: datastore.key(['user', email]),
      data: {
        email,
        createdOn: new Date()
      }
    });

    console.log(`Created user ${email}`);

    output.publishMessage({
      json: <CreateUserResponse>{
        type: data.type,
        to: data.from,
        code: 204,
        seq: data.seq
      }
    })
  } catch (e) {
    console.error(e)
    output.publishMessage({
      json: <CreateUserResponse>{
        type: data.type,
        to: data.from,
        seq: data.seq,
        code: 500,
        message: e.message
      }
    })
  }
}