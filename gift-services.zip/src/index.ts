import { Command } from 'commander';
import Fastify from 'fastify';
import { main as userMain } from './user';
import { main as gatewayMain } from './gateway';
import { main as stateMain } from './state';

const Services = {
  user: userMain,
  gateway: gatewayMain,
  state: stateMain
}

const fastify = Fastify({
  // logger: true
});

const program = new Command();
program
  .name('gift-services')
  .version('1.0.0')
  .argument('<service>', `The service to run (${Object.keys(Services).join(',')})`);

program.parse(process.argv);

const service = program.args[0];
const func = Services[service];
if (func) {
  console.log(`Starting ${service} service`)
  try {
    func();
    console.log("Started");
  } catch (e) {
    throw e;
  }

  // Standup http for use with CloudRun
  if (process.env.NODE_ENV === 'production') {
  fastify.get('/', (_request, reply) => {
    reply.send('Healthy')
  });
  
  fastify.listen({
    port: parseInt(process.env.PORT) || 9000,
    host: '0.0.0.0'
  }, (err, address) => {
    if (err) throw err;
    console.log(`Listening on ${address} as service ${service}`)
  });
  }
} else {
  console.log(`Service ${service} not found`);
}