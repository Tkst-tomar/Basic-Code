/**
 * API gateway
 */
import { WebSocketServer } from 'ws';
import { PubSub } from '@google-cloud/pubsub';
import { randomUUID } from 'crypto';
import { createMessageHandler, type Request } from './common';

const InstanceId = process.env.NODE_ENV === 'production' ? randomUUID() : 'local';
const pubsub = new PubSub({projectId: 'gift-353614'});
let nextIndex = 0;
const userToConnection = {}

const EventMapping = {
  // User service
  auth: (id, json) => {
    // Write other kinds of functions
  },
  createUser: forward('user-service'),

  // State service (until we break these out)
  getFeed: forward('state-service'),
  getWallet: forward('state-service'),
  openGift: forward('state-service'),
  keepGift: forward('state-service'),
  regiftGift: forward('state-service'),
  redeemGift: forward('state-service')
}

function forward(topicName: string) {
  return (id: string, json: any) => pubsub.topic(topicName).publishMessage({ json: {
    ...json,
    from: id
  } });
}

export async function main() {
  const userOutputTopic = pubsub.topic('user-output');
  const subscriptionName = `user-output-sub-${InstanceId}`;
  const userOuptutSub = await userOutputTopic.exists() ?
    userOutputTopic.subscription(subscriptionName) :
    (await userOutputTopic.createSubscription(subscriptionName))[0];
  
  userOuptutSub.on('message', createMessageHandler(msg => {
    const {to, ...data} = msg;
    console.log("Message to user", msg)
    const connection = userToConnection[to];
    connection && connection.send(JSON.stringify(data));
  }));

  userOuptutSub.on('error', error => {
    console.error('Received error:', error);
    process.exit(1);
  });

  const wss = new WebSocketServer({ port: 8081 });
  wss.on('connection', ws => {
    // Asign the connection a random number for testing before auth is ready
    const id = nextIndex++;
    userToConnection[id] = ws;

    console.log(`New connection ID=${id}`)

    ws.on('message', async (msg) => {
      try {
        const req = JSON.parse(msg);

        const func = EventMapping[req.type];
        if (!func) {
          console.warn(`Unknown event ${req.type}`);
          // Disconnect?
          return;
        }

        await func(id, req);
      } catch (e) {
        console.error("Gateway: " + e.message);
      }
    });

    ws.on('close', () => {
      delete userToConnection[id];
    });
  });
}