import { Message } from "@google-cloud/pubsub";

export interface Request {
  type: string;
  from: string;
  seq: number;
}

export interface Response {
  to: string;
  code: number;
}

export function createMessageHandler(handler: (data: any) => void) {
  return async (msg: Message) => {
    try {
      const data = JSON.parse(msg.data.toString());
      console.log(data)
      console.log(`> ${data.type}`)
      await handler(data);
    } catch (e) {
      console.error(e)
    } finally {
      msg.ack();
    }
  }
}

export function createMessageRouter(mapping: {[type: string]: Function}, extra: any) {
  return (data: any) => {
    const func = mapping[data.type];
    return func && func(data, extra);
  }
}