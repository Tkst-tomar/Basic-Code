import { PubSub, Topic } from '@google-cloud/pubsub';
import { Datastore } from '@google-cloud/datastore';
import { createMessageHandler, createMessageRouter, type Request, type Response } from './common';

interface GetFeedRequest extends Request {
  // nothing yet
}

interface GetFeedResponse extends Response {}

interface GetWalletRequest extends Request {}
interface GetWallletResponse extends Response {}

interface OpenGiftRequest extends Request {}
interface OpenGiftResponse extends Response {}

interface KeepGiftRequest extends Request {}
interface KeepGiftResponse extends Response {}

interface RegiftGiftRequest extends Request {}
interface RegiftGiftResponse extends Response {}

interface RedeemGiftRequest extends Request {}
interface RedeemGiftResponse extends Response {}

const pubsub = new PubSub({projectId: 'gift-353614'});
const datastore = new Datastore({projectId: 'gift-353614'});

const EventMapping = {
  getFeed,
  getWallet,
  openGift,
  keepGift,
  regiftGift,
  redeemGift
}

export async function main() {
  const stateServiceSub = await pubsub.subscription('state-service-sub');
  const userOutputTopic = pubsub.topic('user-output');

  stateServiceSub.on('message', createMessageHandler(createMessageRouter(EventMapping, userOutputTopic)));
  stateServiceSub.on('error', error => {
    console.error('Received error:', error);
    process.exit(1);
  });
}

async function getFeed(data: GetFeedRequest, output: Topic) {
}

async function getWallet(data: GetWalletRequest, output: Topic) {
}

async function openGift(data: OpenGiftRequest, output: Topic) {
}

async function keepGift(data: GetWalletRequest, output: Topic) {
}

async function regiftGift(data: GetWalletRequest, output: Topic) {
}

async function redeemGift(data: GetWalletRequest, output: Topic) {
}