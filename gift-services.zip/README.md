# gift-services

Serivces:
- Gateway - Websocket API gateway
- User - Authentication, user creation, user profiles
- State - generic service to place things while we figure things out

User actions:
- Load feed with live updates
- Load wallet with live updates
- Open timer based gift
- Open regift
- Keep gift
- Regift gift (& receiving user gets email or phone notification - gift parked until they join for 'x' days)
- Load gift from wallet with redemption info and expiration etc
- Redeem code (user scanned qr code to redeem)





```sh
npm run dev -- <service name>
```

> Note: Transition from Cloud Run to GKE

Building and running docker service container:

```sh
docker build -t giftservices .
docker run giftservices <servicename>
```